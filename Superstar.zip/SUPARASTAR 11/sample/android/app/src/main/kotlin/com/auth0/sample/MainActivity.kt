package com.auth0.sample

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
